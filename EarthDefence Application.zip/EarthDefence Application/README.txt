This game requires Java already installed on this computer, the version that is being used on time of upload is 
Version 8 update 131
Build 1.8.0_131-b11

Have fun any enjoy the game